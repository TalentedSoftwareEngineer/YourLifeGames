import React from 'react'

function cancel() {
  return (
    <div>cancel</div>
  )
}

export default cancel
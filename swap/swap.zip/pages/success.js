import React from 'react'

function success() {
  return (
    <div>success</div>
  )
}

export default success